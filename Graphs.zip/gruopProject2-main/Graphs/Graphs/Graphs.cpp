#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define WINVER 0x0501
#define _WIN32_WINNT 0x0501
#define _WIN32_IE 0x0500

#pragma warning(disable:28251) // ��������� �������������� �� ���������� WinMain

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string>
#include <vector>
#include <cmath>
#include <cstdio>
#include <ctime>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "kernel32.lib")

// ���������� GDIPlus ��� ������ � PNG
#include <gdiplus.h>
using namespace Gdiplus;
using namespace std;

// ���������
const int WINDOW_WIDTH = 1300;
const int WINDOW_HEIGHT = 850;
const int GRAPH_AREA_X = 320;
const int GRAPH_AREA_Y = 80;
const int GRAPH_WIDTH = 920;
const int GRAPH_HEIGHT = 700;
const int CONTROL_PANEL_X = 30;
const int CONTROL_PANEL_Y = 80;
const int CONTROL_WIDTH = 260;

// ����� ��� ������������ �������
const COLORREF COLOR_BG_MAIN = RGB(245, 245, 250);
const COLORREF COLOR_PANEL = RGB(255, 255, 255);
const COLORREF COLOR_ACCENT = RGB(70, 130, 200);
const COLORREF COLOR_ACCENT_LIGHT = RGB(100, 160, 230);
const COLORREF COLOR_TEXT = RGB(50, 50, 70);
const COLORREF COLOR_BORDER = RGB(200, 200, 220);
const COLORREF COLOR_GRAPH_BG = RGB(255, 255, 255);
const COLORREF COLOR_GRID = RGB(230, 230, 240);
const COLORREF COLOR_AXIS = RGB(80, 80, 100);
const COLORREF COLOR_HOVER = RGB(230, 240, 255);

// �������������� ��������� ����������
enum ControlIDs {
    ID_FUNCTION_INPUT = 1001,
    ID_ADD_BUTTON,
    ID_REMOVE_BUTTON,
    ID_CLEAR_BUTTON,
    ID_FUNCTION_LIST,
    ID_X_MIN,
    ID_X_MAX,
    ID_Y_MIN,
    ID_Y_MAX,
    ID_POINTS,
    ID_UPDATE_BUTTON,
    ID_EXPORT_BUTTON,
    ID_IMPORT_BUTTON,
    ID_GRID_CHECK,
    ID_LEGEND_CHECK,
    ID_ZOOM_IN,
    ID_ZOOM_OUT,
    ID_RESET,
    ID_HISTORY_LIST,
    ID_THEME_TOGGLE
};

// ��������� �������
struct Function {
    string expression;
    COLORREF color;
    bool visible;

    Function() : expression(""), color(RGB(0, 0, 255)), visible(true) {}
};

// ���������� ����������
HWND hMainWindow = NULL;
HWND hFunctionInput = NULL;
HWND hAddButton = NULL;
HWND hRemoveButton = NULL;
HWND hClearButton = NULL;
HWND hFunctionList = NULL;
HWND hXMinInput = NULL;
HWND hXMaxInput = NULL;
HWND hYMinInput = NULL;
HWND hYMaxInput = NULL;
HWND hPointsInput = NULL;
HWND hUpdateButton = NULL;
HWND hExportButton = NULL;
HWND hImportButton = NULL;
HWND hGridCheck = NULL;
HWND hLegendCheck = NULL;
HWND hZoomIn = NULL;
HWND hZoomOut = NULL;
HWND hReset = NULL;
HWND hHistoryList = NULL;
HWND hThemeButton = NULL;

// GDIPlus �����
ULONG_PTR gdiplusToken;

vector<Function> functions;
vector<COLORREF> colors = {
    RGB(230, 70, 70),    // ����-�������
    RGB(70, 130, 230),   // ����-�����
    RGB(70, 180, 70),    // ����-�������
    RGB(255, 150, 50),   // ���������
    RGB(180, 70, 180),   // ����������
    RGB(255, 200, 50),   // ������
    RGB(50, 180, 180),   // ���������
    RGB(230, 100, 150),  // �������
    RGB(150, 150, 150),  // �����
    RGB(180, 120, 70)    // ����������
};

double xMin = -10.0, xMax = 10.0;
double yMin = -10.0, yMax = 10.0;
int pointCount = 1000;
bool showGrid = true;
bool showLegend = true;
bool darkTheme = false;
int currentColorIndex = 0;
bool isDragging = false;
POINT lastMousePos = { 0, 0 };
HBRUSH hBgBrush = NULL;
HBRUSH hPanelBrush = NULL;
HPEN hGridPen = NULL;
HPEN hAxisPen = NULL;
HPEN hBorderPen = NULL;
HFONT hFontTitle = NULL;
HFONT hFontNormal = NULL;
HFONT hFontSmall = NULL;
HINSTANCE hInst = NULL;

// ��������� �������
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void AddControls(HWND hwnd);
void DrawGraph(HDC hdc);
double EvaluateFunction(const string& expr, double x);
void AddFunction();
void RemoveFunction();
void ClearFunctions();
void UpdateGraph();
void ExportGraph();
void ImportFunctions();
void ToggleGrid();
void ToggleLegend();
void ToggleTheme();
void ZoomIn();
void ZoomOut();
void ResetView();
void AddToHistory(const string& expr);
void DrawGrid(HDC hdc);
void DrawAxes(HDC hdc);
void DrawFunction(HDC hdc, const Function& func);
void DrawLegend(HDC hdc);
double MapXToScreen(double x);
double MapYToScreen(double y);
double MapScreenToX(int screenX);
double MapScreenToY(int screenY);
vector<double> GenerateXValues();
bool ValidateExpression(const string& expr);
void UpdateInputFields();
string RemoveSpaces(string str);
void ApplyModernStyle(HWND hwnd);
HWND CreateModernControl(const char* className, const char* windowName, DWORD style,
    int x, int y, int width, int height, HWND parent, HMENU menu);

// �������� ��������
string RemoveSpaces(string str) {
    string result;
    for (size_t i = 0; i < str.length(); i++) {
        if (str[i] != ' ') {
            result += str[i];
        }
    }
    return result;
}

// ���������� ����� �����
void UpdateInputFields() {
    char buffer[32];
    sprintf(buffer, "%.1f", xMin);
    SetWindowTextA(hXMinInput, buffer);
    sprintf(buffer, "%.1f", xMax);
    SetWindowTextA(hXMaxInput, buffer);
    sprintf(buffer, "%.1f", yMin);
    SetWindowTextA(hYMinInput, buffer);
    sprintf(buffer, "%.1f", yMax);
    SetWindowTextA(hYMaxInput, buffer);
}

// �������������� ���������
double MapXToScreen(double x) {
    return GRAPH_AREA_X + (x - xMin) * GRAPH_WIDTH / (xMax - xMin);
}

double MapYToScreen(double y) {
    return GRAPH_AREA_Y + GRAPH_HEIGHT - (y - yMin) * GRAPH_HEIGHT / (yMax - yMin);
}

double MapScreenToX(int screenX) {
    return xMin + (screenX - GRAPH_AREA_X) * (xMax - xMin) / GRAPH_WIDTH;
}

double MapScreenToY(int screenY) {
    return yMin + (GRAPH_AREA_Y + GRAPH_HEIGHT - screenY) * (yMax - yMin) / GRAPH_HEIGHT;
}

// ��������� �������� X
vector<double> GenerateXValues() {
    vector<double> xValues(pointCount);
    double step = (xMax - xMin) / (pointCount - 1);
    for (int i = 0; i < pointCount; i++) {
        xValues[i] = xMin + i * step;
    }
    return xValues;
}

// ���������� �������
double EvaluateFunction(const string& expr, double x) {
    string e = RemoveSpaces(expr);

    if (e == "sin(x)") return sin(x);
    if (e == "cos(x)") return cos(x);
    if (e == "tan(x)") return tan(x);
    if (e == "exp(x)") return exp(x);
    if (e == "log(x)") return (x > 0) ? log(x) : 0;
    if (e == "ln(x)") return (x > 0) ? log(x) : 0;
    if (e == "sqrt(x)") return (x >= 0) ? sqrt(x) : 0;
    if (e == "abs(x)") return fabs(x);
    if (e == "x") return x;
    if (e == "x^2") return x * x;
    if (e == "x^3") return x * x * x;
    if (e == "1/x") return (x != 0) ? 1.0 / x : 0;
    if (e == "sinh(x)") return sinh(x);
    if (e == "cosh(x)") return cosh(x);
    if (e == "tanh(x)") return tanh(x);

    return 0;
}

// ��������� ���������
bool ValidateExpression(const string& expr) {
    string e = RemoveSpaces(expr);

    vector<string> validExprs = {
        "sin(x)", "cos(x)", "tan(x)", "exp(x)", "log(x)", "ln(x)",
        "sqrt(x)", "abs(x)", "x", "x^2", "x^3", "1/x",
        "sinh(x)", "cosh(x)", "tanh(x)"
    };

    for (size_t i = 0; i < validExprs.size(); i++) {
        if (e == validExprs[i]) return true;
    }
    return false;
}

// ���������� � �������
void AddToHistory(const string& expr) {
    SendMessageA(hHistoryList, LB_ADDSTRING, 0, (LPARAM)expr.c_str());
    int count = (int)SendMessageA(hHistoryList, LB_GETCOUNT, 0, 0);
    SendMessageA(hHistoryList, LB_SETTOPINDEX, count - 1, 0);
}

// ���������� �������
void AddFunction() {
    char buffer[256];
    GetWindowTextA(hFunctionInput, buffer, 256);

    string expr(buffer);
    expr = RemoveSpaces(expr);

    if (expr.empty()) {
        MessageBoxA(hMainWindow, "������� �������!", "������", MB_OK | MB_ICONWARNING);
        return;
    }

    if (!ValidateExpression(expr)) {
        MessageBoxA(hMainWindow,
            "�������������� �������:\n"
            "sin(x), cos(x), tan(x), exp(x), log(x), ln(x),\n"
            "sqrt(x), abs(x), x, x^2, x^3, 1/x,\n"
            "sinh(x), cosh(x), tanh(x)",
            "������", MB_OK | MB_ICONWARNING);
        return;
    }

    for (size_t i = 0; i < functions.size(); i++) {
        if (functions[i].expression == expr) {
            MessageBoxA(hMainWindow, "��� ������� ��� ���������!",
                "��������������", MB_OK | MB_ICONINFORMATION);
            return;
        }
    }

    Function func;
    func.expression = expr;
    func.color = colors[currentColorIndex % colors.size()];
    func.visible = true;

    functions.push_back(func);
    currentColorIndex++;

    SendMessageA(hFunctionList, LB_ADDSTRING, 0, (LPARAM)expr.c_str());
    AddToHistory(expr);

    SetWindowTextA(hFunctionInput, "");
    InvalidateRect(hMainWindow, NULL, TRUE);
}

// �������� �������
void RemoveFunction() {
    int index = (int)SendMessageA(hFunctionList, LB_GETCURSEL, 0, 0);
    if (index != LB_ERR) {
        SendMessageA(hFunctionList, LB_DELETESTRING, index, 0);
        functions.erase(functions.begin() + index);
        InvalidateRect(hMainWindow, NULL, TRUE);
    }
}

// ������� ���� �������
void ClearFunctions() {
    SendMessageA(hFunctionList, LB_RESETCONTENT, 0, 0);
    functions.clear();
    currentColorIndex = 0;
    InvalidateRect(hMainWindow, NULL, TRUE);
}

// ���������� �������
void UpdateGraph() {
    char buffer[32];

    GetWindowTextA(hXMinInput, buffer, 32);
    xMin = atof(buffer);
    GetWindowTextA(hXMaxInput, buffer, 32);
    xMax = atof(buffer);
    GetWindowTextA(hYMinInput, buffer, 32);
    yMin = atof(buffer);
    GetWindowTextA(hYMaxInput, buffer, 32);
    yMax = atof(buffer);
    GetWindowTextA(hPointsInput, buffer, 32);
    pointCount = atoi(buffer);

    if (pointCount < 100) pointCount = 100;
    if (pointCount > 5000) pointCount = 5000;

    InvalidateRect(hMainWindow, NULL, TRUE);
}

// ��������� �������
void DrawGraph(HDC hdc) {
    SelectObject(hdc, hFontNormal);
    SetBkMode(hdc, TRANSPARENT);

    // ������ ������� �������
    HBRUSH hGraphBg = CreateSolidBrush(COLOR_GRAPH_BG);
    RECT graphRect = { GRAPH_AREA_X, GRAPH_AREA_Y,
                      GRAPH_AREA_X + GRAPH_WIDTH, GRAPH_AREA_Y + GRAPH_HEIGHT };
    FillRect(hdc, &graphRect, hGraphBg);
    DeleteObject(hGraphBg);

    // �����
    SelectObject(hdc, hBorderPen);
    SelectObject(hdc, GetStockObject(NULL_BRUSH));
    Rectangle(hdc, GRAPH_AREA_X, GRAPH_AREA_Y,
        GRAPH_AREA_X + GRAPH_WIDTH, GRAPH_AREA_Y + GRAPH_HEIGHT);

    SaveDC(hdc);
    IntersectClipRect(hdc, GRAPH_AREA_X + 1, GRAPH_AREA_Y + 1,
        GRAPH_AREA_X + GRAPH_WIDTH - 1, GRAPH_AREA_Y + GRAPH_HEIGHT - 1);

    if (showGrid) DrawGrid(hdc);
    DrawAxes(hdc);

    for (size_t i = 0; i < functions.size(); i++) {
        DrawFunction(hdc, functions[i]);
    }

    RestoreDC(hdc, -1);

    if (showLegend && !functions.empty()) {
        DrawLegend(hdc);
    }
}

// ��������� �����
void DrawGrid(HDC hdc) {
    SelectObject(hdc, hGridPen);
    SetTextColor(hdc, COLOR_TEXT);
    SetBkMode(hdc, TRANSPARENT);

    double xStep = (xMax - xMin) / 20.0;
    for (double x = xMin; x <= xMax; x += xStep) {
        int screenX = (int)MapXToScreen(x);
        if (screenX > GRAPH_AREA_X && screenX < GRAPH_AREA_X + GRAPH_WIDTH) {
            MoveToEx(hdc, screenX, GRAPH_AREA_Y, NULL);
            LineTo(hdc, screenX, GRAPH_AREA_Y + GRAPH_HEIGHT);

            if (fabs(x) > 0.001) {
                char buffer[32];
                sprintf(buffer, "%.1f", x);
                TextOutA(hdc, screenX - 20, GRAPH_AREA_Y + GRAPH_HEIGHT + 8, buffer, (int)strlen(buffer));
            }
        }
    }

    double yStep = (yMax - yMin) / 20.0;
    for (double y = yMin; y <= yMax; y += yStep) {
        int screenY = (int)MapYToScreen(y);
        if (screenY > GRAPH_AREA_Y && screenY < GRAPH_AREA_Y + GRAPH_HEIGHT) {
            MoveToEx(hdc, GRAPH_AREA_X, screenY, NULL);
            LineTo(hdc, GRAPH_AREA_X + GRAPH_WIDTH, screenY);

            if (fabs(y) > 0.001) {
                char buffer[32];
                sprintf(buffer, "%.1f", y);
                TextOutA(hdc, GRAPH_AREA_X - 45, screenY - 10, buffer, (int)strlen(buffer));
            }
        }
    }
}

// ��������� ����
void DrawAxes(HDC hdc) {
    SelectObject(hdc, hAxisPen);

    int yZero = (int)MapYToScreen(0);
    if (yZero >= GRAPH_AREA_Y && yZero <= GRAPH_AREA_Y + GRAPH_HEIGHT) {
        MoveToEx(hdc, GRAPH_AREA_X, yZero, NULL);
        LineTo(hdc, GRAPH_AREA_X + GRAPH_WIDTH, yZero);

        // ������� X
        MoveToEx(hdc, GRAPH_AREA_X + GRAPH_WIDTH - 10, yZero - 5, NULL);
        LineTo(hdc, GRAPH_AREA_X + GRAPH_WIDTH, yZero);
        LineTo(hdc, GRAPH_AREA_X + GRAPH_WIDTH - 10, yZero + 5);

        TextOutA(hdc, GRAPH_AREA_X + GRAPH_WIDTH - 20, yZero - 20, "X", 1);
    }

    int xZero = (int)MapXToScreen(0);
    if (xZero >= GRAPH_AREA_X && xZero <= GRAPH_AREA_X + GRAPH_WIDTH) {
        MoveToEx(hdc, xZero, GRAPH_AREA_Y, NULL);
        LineTo(hdc, xZero, GRAPH_AREA_Y + GRAPH_HEIGHT);

        // ������� Y
        MoveToEx(hdc, xZero - 5, GRAPH_AREA_Y + 10, NULL);
        LineTo(hdc, xZero, GRAPH_AREA_Y);
        LineTo(hdc, xZero + 5, GRAPH_AREA_Y + 10);

        TextOutA(hdc, xZero + 10, GRAPH_AREA_Y + 10, "Y", 1);
    }
}

// ��������� �������
void DrawFunction(HDC hdc, const Function& func) {
    if (!func.visible) return;

    HPEN hFuncPen = CreatePen(PS_SOLID, 2, func.color);
    SelectObject(hdc, hFuncPen);

    vector<double> xValues = GenerateXValues();
    bool firstPoint = true;
    int lastX = 0, lastY = 0;

    for (int i = 0; i < (int)xValues.size(); i++) {
        double x = xValues[i];
        double y = EvaluateFunction(func.expression, x);

        if (!isnan(y) && !isinf(y) && y > yMin - 2 && y < yMax + 2) {
            int screenX = (int)MapXToScreen(x);
            int screenY = (int)MapYToScreen(y);

            if (firstPoint) {
                firstPoint = false;
            }
            else {
                if (abs(screenX - lastX) < GRAPH_WIDTH) {
                    MoveToEx(hdc, lastX, lastY, NULL);
                    LineTo(hdc, screenX, screenY);
                }
            }
            lastX = screenX;
            lastY = screenY;
        }
        else {
            firstPoint = true;
        }
    }

    DeleteObject(hFuncPen);
}

// ��������� �������
void DrawLegend(HDC hdc) {
    int legendX = GRAPH_AREA_X + GRAPH_WIDTH - 200;
    int legendY = GRAPH_AREA_Y + 20;
    int itemHeight = 24;
    int padding = 10;

    int height = (int)functions.size() * itemHeight + padding * 2;
    int width = 180;

    // ���
    HBRUSH hLegendBg = CreateSolidBrush(RGB(255, 255, 255));
    HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hLegendBg);
    HPEN hOldPen = (HPEN)SelectObject(hdc, GetStockObject(NULL_PEN));

    RECT legendRect = { legendX, legendY, legendX + width, legendY + height };
    RoundRect(hdc, legendRect.left, legendRect.top, legendRect.right, legendRect.bottom, 10, 10);

    SelectObject(hdc, hOldBrush);
    SelectObject(hdc, hOldPen);
    DeleteObject(hLegendBg);

    // �����
    SelectObject(hdc, hBorderPen);
    SelectObject(hdc, GetStockObject(NULL_BRUSH));
    RoundRect(hdc, legendRect.left, legendRect.top, legendRect.right, legendRect.bottom, 10, 10);

    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, COLOR_TEXT);

    int y = legendY + padding;
    for (size_t i = 0; i < functions.size(); i++) {
        if (functions[i].visible) {
            // ������� ���������
            HBRUSH hColorBrush = CreateSolidBrush(functions[i].color);
            RECT colorRect = { legendX + padding, y + 4, legendX + padding + 16, y + 20 };
            FillRect(hdc, &colorRect, hColorBrush);
            DeleteObject(hColorBrush);

            // ����� ������ ����������
            SelectObject(hdc, GetStockObject(BLACK_PEN));
            SelectObject(hdc, GetStockObject(NULL_BRUSH));
            Rectangle(hdc, colorRect.left, colorRect.top, colorRect.right, colorRect.bottom);

            // �������� �������
            string shortName = functions[i].expression;
            TextOutA(hdc, legendX + padding + 24, y, shortName.c_str(), (int)shortName.length());

            y += itemHeight;
        }
    }
}

// ������� �������
void ExportGraph() {
    MessageBoxA(hMainWindow, "������� �������� ����� ��������� � ��������� ����������!",
        "�������", MB_OK | MB_ICONINFORMATION);
}

// ������ �������
void ImportFunctions() {
    MessageBoxA(hMainWindow, "������� ������� ����� ��������� � ��������� ����������!",
        "������", MB_OK | MB_ICONINFORMATION);
}

// ������������ �����
void ToggleGrid() {
    showGrid = (SendMessageA(hGridCheck, BM_GETCHECK, 0, 0) == BST_CHECKED);
    InvalidateRect(hMainWindow, NULL, TRUE);
}

// ������������ �������
void ToggleLegend() {
    showLegend = (SendMessageA(hLegendCheck, BM_GETCHECK, 0, 0) == BST_CHECKED);
    InvalidateRect(hMainWindow, NULL, TRUE);
}

// ������������ ����
void ToggleTheme() {
    darkTheme = !darkTheme;
    InvalidateRect(hMainWindow, NULL, TRUE);
}

// ����������
void ZoomIn() {
    double centerX = (xMin + xMax) / 2.0;
    double centerY = (yMin + yMax) / 2.0;
    double width = (xMax - xMin) * 0.8;
    double height = (yMax - yMin) * 0.8;

    xMin = centerX - width / 2.0;
    xMax = centerX + width / 2.0;
    yMin = centerY - height / 2.0;
    yMax = centerY + height / 2.0;

    UpdateInputFields();
    InvalidateRect(hMainWindow, NULL, TRUE);
}

// ��������
void ZoomOut() {
    double centerX = (xMin + xMax) / 2.0;
    double centerY = (yMin + yMax) / 2.0;
    double width = (xMax - xMin) * 1.25;
    double height = (yMax - yMin) * 1.25;

    xMin = centerX - width / 2.0;
    xMax = centerX + width / 2.0;
    yMin = centerY - height / 2.0;
    yMax = centerY + height / 2.0;

    UpdateInputFields();
    InvalidateRect(hMainWindow, NULL, TRUE);
}

// ����� ��������
void ResetView() {
    SetWindowTextA(hXMinInput, "-10");
    SetWindowTextA(hXMaxInput, "10");
    SetWindowTextA(hYMinInput, "-10");
    SetWindowTextA(hYMaxInput, "10");
    SetWindowTextA(hPointsInput, "1000");

    xMin = -10.0; xMax = 10.0;
    yMin = -10.0; yMax = 10.0;
    pointCount = 1000;

    InvalidateRect(hMainWindow, NULL, TRUE);
}

// ���������� ������������ ����� � ��������� ����������
void ApplyModernStyle(HWND hwnd) {
    if (hFontNormal && hwnd) {
        SendMessageA(hwnd, WM_SETFONT, (WPARAM)hFontNormal, TRUE);
    }
}

// �������� �������� ���������� � ����������� �����
HWND CreateModernControl(const char* className, const char* windowName, DWORD style,
    int x, int y, int width, int height, HWND parent, HMENU menu) {
    return CreateWindowExA(0, className, windowName, style | WS_CHILD | WS_VISIBLE,
        x, y, width, height, parent, menu, hInst, NULL);
}

// ���������� ��������� ����������
void AddControls(HWND hwnd) {
    int yPos = CONTROL_PANEL_Y;

    // ������ ����� �������
    CreateModernControl("STATIC", "", WS_VISIBLE | WS_CHILD | SS_WHITERECT,
        CONTROL_PANEL_X - 5, yPos - 5, CONTROL_WIDTH + 10, 120,
        hwnd, NULL);

    // ��������� ������
    HWND hFuncTitle = CreateModernControl("STATIC", "���������� �������",
        WS_VISIBLE | WS_CHILD | SS_LEFT,
        CONTROL_PANEL_X, yPos - 2, CONTROL_WIDTH, 25,
        hwnd, NULL);
    SendMessageA(hFuncTitle, WM_SETFONT, (WPARAM)hFontSmall, TRUE);

    yPos += 25;

    CreateModernControl("STATIC", "f(x) =", WS_VISIBLE | WS_CHILD | SS_RIGHT,
        CONTROL_PANEL_X, yPos, 50, 30,
        hwnd, NULL);

    hFunctionInput = CreateModernControl("EDIT", "",
        WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL,
        CONTROL_PANEL_X + 55, yPos, 155, 30,
        hwnd, (HMENU)ID_FUNCTION_INPUT);
    ApplyModernStyle(hFunctionInput);

    yPos += 40;

    // ������
    hAddButton = CreateModernControl("BUTTON", "��������",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        CONTROL_PANEL_X, yPos, 75, 32,
        hwnd, (HMENU)ID_ADD_BUTTON);
    ApplyModernStyle(hAddButton);

    hRemoveButton = CreateModernControl("BUTTON", "�������",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        CONTROL_PANEL_X + 85, yPos, 75, 32,
        hwnd, (HMENU)ID_REMOVE_BUTTON);
    ApplyModernStyle(hRemoveButton);

    hClearButton = CreateModernControl("BUTTON", "��������",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        CONTROL_PANEL_X + 170, yPos, 75, 32,
        hwnd, (HMENU)ID_CLEAR_BUTTON);
    ApplyModernStyle(hClearButton);

    yPos += 50;

    // ������ �������� �������
    CreateModernControl("STATIC", "", WS_VISIBLE | WS_CHILD | SS_WHITERECT,
        CONTROL_PANEL_X - 5, yPos - 5, CONTROL_WIDTH + 10, 120,
        hwnd, NULL);

    HWND hListTitle = CreateModernControl("STATIC", "�������� �������",
        WS_VISIBLE | WS_CHILD | SS_LEFT,
        CONTROL_PANEL_X, yPos - 2, CONTROL_WIDTH, 25,
        hwnd, NULL);
    SendMessageA(hListTitle, WM_SETFONT, (WPARAM)hFontSmall, TRUE);

    yPos += 25;

    hFunctionList = CreateModernControl("LISTBOX", "",
        WS_VISIBLE | WS_CHILD | WS_BORDER | WS_VSCROLL | LBS_NOTIFY,
        CONTROL_PANEL_X, yPos, CONTROL_WIDTH, 80,
        hwnd, (HMENU)ID_FUNCTION_LIST);
    ApplyModernStyle(hFunctionList);

    yPos += 100;

    // ������ ��������
    CreateModernControl("STATIC", "", WS_VISIBLE | WS_CHILD | SS_WHITERECT,
        CONTROL_PANEL_X - 5, yPos - 5, CONTROL_WIDTH + 10, 190,
        hwnd, NULL);

    HWND hSettingsTitle = CreateModernControl("STATIC", "��������� �����������",
        WS_VISIBLE | WS_CHILD | SS_LEFT,
        CONTROL_PANEL_X, yPos - 2, CONTROL_WIDTH, 25,
        hwnd, NULL);
    SendMessageA(hSettingsTitle, WM_SETFONT, (WPARAM)hFontSmall, TRUE);

    yPos += 25;

    // X ��������
    CreateModernControl("STATIC", "X:", WS_VISIBLE | WS_CHILD | SS_RIGHT,
        CONTROL_PANEL_X, yPos, 25, 25,
        hwnd, NULL);

    hXMinInput = CreateModernControl("EDIT", "-10",
        WS_VISIBLE | WS_CHILD | WS_BORDER | ES_NUMBER,
        CONTROL_PANEL_X + 30, yPos, 55, 25,
        hwnd, (HMENU)ID_X_MIN);
    ApplyModernStyle(hXMinInput);

    CreateModernControl("STATIC", "��", WS_VISIBLE | WS_CHILD,
        CONTROL_PANEL_X + 90, yPos, 20, 25,
        hwnd, NULL);

    hXMaxInput = CreateModernControl("EDIT", "10",
        WS_VISIBLE | WS_CHILD | WS_BORDER | ES_NUMBER,
        CONTROL_PANEL_X + 115, yPos, 55, 25,
        hwnd, (HMENU)ID_X_MAX);
    ApplyModernStyle(hXMaxInput);

    yPos += 35;

    // Y ��������
    CreateModernControl("STATIC", "Y:", WS_VISIBLE | WS_CHILD | SS_RIGHT,
        CONTROL_PANEL_X, yPos, 25, 25,
        hwnd, NULL);

    hYMinInput = CreateModernControl("EDIT", "-10",
        WS_VISIBLE | WS_CHILD | WS_BORDER | ES_NUMBER,
        CONTROL_PANEL_X + 30, yPos, 55, 25,
        hwnd, (HMENU)ID_Y_MIN);
    ApplyModernStyle(hYMinInput);

    CreateModernControl("STATIC", "��", WS_VISIBLE | WS_CHILD,
        CONTROL_PANEL_X + 90, yPos, 20, 25,
        hwnd, NULL);

    hYMaxInput = CreateModernControl("EDIT", "10",
        WS_VISIBLE | WS_CHILD | WS_BORDER | ES_NUMBER,
        CONTROL_PANEL_X + 115, yPos, 55, 25,
        hwnd, (HMENU)ID_Y_MAX);
    ApplyModernStyle(hYMaxInput);

    yPos += 35;

    // ���������� �����
    CreateModernControl("STATIC", "�����:", WS_VISIBLE | WS_CHILD | SS_RIGHT,
        CONTROL_PANEL_X, yPos, 50, 25,
        hwnd, NULL);

    hPointsInput = CreateModernControl("EDIT", "1000",
        WS_VISIBLE | WS_CHILD | WS_BORDER | ES_NUMBER,
        CONTROL_PANEL_X + 55, yPos, 60, 25,
        hwnd, (HMENU)ID_POINTS);
    ApplyModernStyle(hPointsInput);

    hUpdateButton = CreateModernControl("BUTTON", "��������",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        CONTROL_PANEL_X + 130, yPos, 100, 25,
        hwnd, (HMENU)ID_UPDATE_BUTTON);
    ApplyModernStyle(hUpdateButton);

    yPos += 40;

    // ��������
    hGridCheck = CreateModernControl("BUTTON", "�������� �����",
        WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX,
        CONTROL_PANEL_X, yPos, 120, 25,
        hwnd, (HMENU)ID_GRID_CHECK);
    ApplyModernStyle(hGridCheck);
    SendMessageA(hGridCheck, BM_SETCHECK, BST_CHECKED, 0);

    yPos += 30;

    hLegendCheck = CreateModernControl("BUTTON", "�������� �������",
        WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX,
        CONTROL_PANEL_X, yPos, 140, 25,
        hwnd, (HMENU)ID_LEGEND_CHECK);
    ApplyModernStyle(hLegendCheck);
    SendMessageA(hLegendCheck, BM_SETCHECK, BST_CHECKED, 0);

    yPos += 45;

    // ������ ���������������
    CreateModernControl("STATIC", "�������", WS_VISIBLE | WS_CHILD,
        CONTROL_PANEL_X, yPos - 5, 60, 20,
        hwnd, NULL);

    yPos += 20;

    hZoomIn = CreateModernControl("BUTTON", "+",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        CONTROL_PANEL_X, yPos, 50, 30,
        hwnd, (HMENU)ID_ZOOM_IN);
    ApplyModernStyle(hZoomIn);

    hZoomOut = CreateModernControl("BUTTON", "-",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        CONTROL_PANEL_X + 60, yPos, 50, 30,
        hwnd, (HMENU)ID_ZOOM_OUT);
    ApplyModernStyle(hZoomOut);

    hReset = CreateModernControl("BUTTON", "�����",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        CONTROL_PANEL_X + 120, yPos, 110, 30,
        hwnd, (HMENU)ID_RESET);
    ApplyModernStyle(hReset);

    yPos += 50;

    // ������ ��������/�������
    hExportButton = CreateModernControl("BUTTON", "�������",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        CONTROL_PANEL_X, yPos, 110, 30,
        hwnd, (HMENU)ID_EXPORT_BUTTON);
    ApplyModernStyle(hExportButton);

    hImportButton = CreateModernControl("BUTTON", "������",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        CONTROL_PANEL_X + 120, yPos, 110, 30,
        hwnd, (HMENU)ID_IMPORT_BUTTON);
    ApplyModernStyle(hImportButton);

    yPos += 50;

    // �������
    CreateModernControl("STATIC", "", WS_VISIBLE | WS_CHILD | SS_WHITERECT,
        CONTROL_PANEL_X - 5, yPos - 5, CONTROL_WIDTH + 10, 120,
        hwnd, NULL);

    HWND hHistoryTitle = CreateModernControl("STATIC", "�������",
        WS_VISIBLE | WS_CHILD | SS_LEFT,
        CONTROL_PANEL_X, yPos - 2, CONTROL_WIDTH, 25,
        hwnd, NULL);
    SendMessageA(hHistoryTitle, WM_SETFONT, (WPARAM)hFontSmall, TRUE);

    yPos += 25;

    hHistoryList = CreateModernControl("LISTBOX", "",
        WS_VISIBLE | WS_CHILD | WS_BORDER | WS_VSCROLL,
        CONTROL_PANEL_X, yPos, CONTROL_WIDTH, 80,
        hwnd, (HMENU)ID_HISTORY_LIST);
    ApplyModernStyle(hHistoryList);
}

// ��������� ����
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CREATE:
        AddControls(hwnd);
        return 0;

    case WM_ERASEBKGND: {
        HDC hdc = (HDC)wParam;
        RECT rc;
        GetClientRect(hwnd, &rc);
        FillRect(hdc, &rc, hBgBrush);
        return 1;
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);

        HDC hdcMem = CreateCompatibleDC(hdc);
        HBITMAP hbmMem = CreateCompatibleBitmap(hdc, WINDOW_WIDTH, WINDOW_HEIGHT);
        HGDIOBJ hOld = SelectObject(hdcMem, hbmMem);

        RECT clientRect;
        GetClientRect(hwnd, &clientRect);
        FillRect(hdcMem, &clientRect, hBgBrush);

        // ������ ���������
        SelectObject(hdcMem, hFontTitle);
        SetBkMode(hdcMem, TRANSPARENT);
        SetTextColor(hdcMem, COLOR_TEXT);
        TextOutA(hdcMem, 30, 20, "����������� �������� 2.0", 24);

        SelectObject(hdcMem, hFontSmall);
        TextOutA(hdcMem, 30, 50, "������������� ���������� �������������� �������", 48);

        // ������ ������
        DrawGraph(hdcMem);

        BitBlt(hdc, 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, hdcMem, 0, 0, SRCCOPY);

        SelectObject(hdcMem, hOld);
        DeleteObject(hbmMem);
        DeleteDC(hdcMem);

        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_COMMAND: {
        int id = LOWORD(wParam);

        switch (id) {
        case ID_ADD_BUTTON: AddFunction(); break;
        case ID_REMOVE_BUTTON: RemoveFunction(); break;
        case ID_CLEAR_BUTTON: ClearFunctions(); break;
        case ID_UPDATE_BUTTON: UpdateGraph(); break;
        case ID_EXPORT_BUTTON: ExportGraph(); break;
        case ID_IMPORT_BUTTON: ImportFunctions(); break;
        case ID_GRID_CHECK: ToggleGrid(); break;
        case ID_LEGEND_CHECK: ToggleLegend(); break;
        case ID_THEME_TOGGLE: ToggleTheme(); break;
        case ID_ZOOM_IN: ZoomIn(); break;
        case ID_ZOOM_OUT: ZoomOut(); break;
        case ID_RESET: ResetView(); break;
        }
        return 0;
    }

    case WM_LBUTTONDOWN: {
        int x = GET_X_LPARAM(lParam);
        int y = GET_Y_LPARAM(lParam);

        if (x >= GRAPH_AREA_X && x <= GRAPH_AREA_X + GRAPH_WIDTH &&
            y >= GRAPH_AREA_Y && y <= GRAPH_AREA_Y + GRAPH_HEIGHT) {
            isDragging = true;
            lastMousePos.x = x;
            lastMousePos.y = y;
            SetCapture(hwnd);
            SetCursor(LoadCursor(NULL, IDC_HAND));
        }
        return 0;
    }

    case WM_MOUSEMOVE: {
        if (isDragging) {
            int x = GET_X_LPARAM(lParam);
            int y = GET_Y_LPARAM(lParam);

            double dx = MapScreenToX(x) - MapScreenToX(lastMousePos.x);
            double dy = MapScreenToY(y) - MapScreenToY(lastMousePos.y);

            xMin -= dx;
            xMax -= dx;
            yMin -= dy;
            yMax -= dy;

            lastMousePos.x = x;
            lastMousePos.y = y;

            UpdateInputFields();
            InvalidateRect(hwnd, NULL, TRUE);
        }
        return 0;
    }

    case WM_LBUTTONUP: {
        isDragging = false;
        ReleaseCapture();
        SetCursor(LoadCursor(NULL, IDC_ARROW));
        return 0;
    }

    case WM_MOUSEWHEEL: {
        int delta = GET_WHEEL_DELTA_WPARAM(wParam);
        double scale = (delta > 0) ? 0.85 : 1.15;

        int x = GET_X_LPARAM(lParam);
        int y = GET_Y_LPARAM(lParam);

        POINT pt = { x, y };
        ScreenToClient(hwnd, &pt);

        if (pt.x >= GRAPH_AREA_X && pt.x <= GRAPH_AREA_X + GRAPH_WIDTH &&
            pt.y >= GRAPH_AREA_Y && pt.y <= GRAPH_AREA_Y + GRAPH_HEIGHT) {

            double mouseX = MapScreenToX(pt.x);
            double mouseY = MapScreenToY(pt.y);

            xMin = mouseX - (mouseX - xMin) * scale;
            xMax = mouseX + (xMax - mouseX) * scale;
            yMin = mouseY - (mouseY - yMin) * scale;
            yMax = mouseY + (yMax - mouseY) * scale;

            UpdateInputFields();
            InvalidateRect(hwnd, NULL, TRUE);
        }
        return 0;
    }

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProcA(hwnd, uMsg, wParam, lParam);
}

// ����� ����� - ���������� ��� MinGW
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    hInst = hInstance;

    // ������������� ����� ��������� ����������
    InitCommonControls();

    // ������������� GDIPlus
    GdiplusStartupInput gdiplusStartupInput;
    GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    // �������� �������
    hFontTitle = CreateFontA(
        20, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Segoe UI"
    );

    hFontNormal = CreateFontA(
        16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Segoe UI"
    );

    hFontSmall = CreateFontA(
        14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Segoe UI"
    );

    // �������� ��������
    hBgBrush = CreateSolidBrush(COLOR_BG_MAIN);
    hPanelBrush = CreateSolidBrush(COLOR_PANEL);
    hGridPen = CreatePen(PS_DOT, 1, COLOR_GRID);
    hAxisPen = CreatePen(PS_SOLID, 2, COLOR_AXIS);
    hBorderPen = CreatePen(PS_SOLID, 1, COLOR_BORDER);

    WNDCLASSA wc = {};
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = hBgBrush;
    wc.lpszClassName = "ModernPlotterClass";

    if (!RegisterClassA(&wc)) {
        MessageBoxA(NULL, "Window Registration Failed!", "Error", MB_OK | MB_ICONERROR);
        return 0;
    }

    hMainWindow = CreateWindowExA(
        0,
        "ModernPlotterClass",
        "����������� �������� 2.0",
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
        CW_USEDEFAULT, CW_USEDEFAULT,
        WINDOW_WIDTH, WINDOW_HEIGHT,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    if (!hMainWindow) {
        MessageBoxA(NULL, "Window Creation Failed!", "Error", MB_OK | MB_ICONERROR);
        return 0;
    }

    ShowWindow(hMainWindow, nCmdShow);
    UpdateWindow(hMainWindow);

    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // ������� ��������
    DeleteObject(hBgBrush);
    DeleteObject(hPanelBrush);
    DeleteObject(hGridPen);
    DeleteObject(hAxisPen);
    DeleteObject(hBorderPen);
    DeleteObject(hFontTitle);
    DeleteObject(hFontNormal);
    DeleteObject(hFontSmall);

    // ���������� GDIPlus
    GdiplusShutdown(gdiplusToken);

    return (int)msg.wParam;
}